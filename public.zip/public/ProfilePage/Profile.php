<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once __DIR__ . '/../headLinks.php'; ?>
    <title>Account Setting</title>
</head>

<body>
    <main class="Profile_Outer">
        <div class="Profile_Container Sidebar">
            <div class="Profile_SidebarContent">

                <button>Start Trade</button>
                <button>Resell History</button>
                <button>Trade History</button>
                <button>Resell NFT</button>

            </div>
            <button id="Profile_LogoutButton">Log Out</button>
        </div>
        <div class="Profile_Container Main">

        </div>
    </main>
</body>
<script src="LogoutFunc.js"></script>

</html>